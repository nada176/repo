import React from 'react';
import HeroHome from '../../components/Hero/HeroHome';

const Services = () => {
  return (
    <div>
      <HeroHome />
    
    </div>
  );
};

export default Services;
