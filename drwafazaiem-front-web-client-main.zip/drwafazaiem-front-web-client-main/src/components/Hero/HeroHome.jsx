import React from 'react';
import './heroHome.css'; // Make sure to create this CSS file for styling

const HeroHome = () => {
  return (
    <div className="heroHome">
      <h1>DIAMONDS</h1>
      <p>ARE FOREVER - SKYCE IS JUST FOR FUN</p>
      {/* Add any additional elements like buttons if needed */}
    </div>
  );
};

export default HeroHome;
